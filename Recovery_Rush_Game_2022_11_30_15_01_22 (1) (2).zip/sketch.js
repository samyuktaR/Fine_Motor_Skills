var gameOneStatus;
var gameTwoStatus;
var gameThreeStatus;
var gameFourStatus;
var menuScreen;


var userX;
var userY;
var userR = 30;

let r1, g1, b1;
let r2, g2, b2;
let r3, g3, b3;
let r4, g4, b4;

var score = 0;

var circOneClicked = false;
var circTwoClicked = false;
var circThreeClicked = false;
var circFourClicked = false;

  r1 = 235;
  g1 = 26;
  b1 = 26;
  r2 = 235;
  g2 = 26;
  b2 = 26;
  r3 = 235;
  g3 = 26;
  b3 = 26;
  r4 = 235;
  g4 = 26;
  b4 = 26;

//GAME TWO CODE
let X = 75;
let Y = 70;
let mazeL;
let color = ('red');
let value = 'yellow';
let timer = 30
var x,y; 

let timer2 = 30
let squareColor1 = 0;
let squareColor2 = 0;
let squareColor3 = 0;
let squareColor4 = 0;
let button;
let options = [0, 1, 2, 3];
let answer1;
let answer2;
let answer3;
let answer4;

let colorsArray = ['blue', 'green', 'purple', 'brown', 'magenta', 'tan', 'white', 'yellow', 'red', 'turquoise']


function preload(){
  shape1 = loadImage("images/Shape1.png");
  shape2 = loadImage("images/Shape2.png");
  shape3 = loadImage("images/Shape3.png");
  menuTraceShape = loadImage("images/ShapeTrace.png");
  }


function setup() {
  createCanvas(440, 490);
  gameOneStatus = 0;
  gameTwoStatus = 0;
  gameThreeStatus = 0;
  gameFourStatus = 0;
  menuScreen = 0;
  squareColor1 = random(255);
  squareColor2 = random(255);
  squareColor3 = random(255);
  squareColor4 = random(255);
  
  }


function draw()   {
  clear();
  //****WORK IN PROGRESS MENU SCREEN, FIXME I WANNA BE PRETTY****
  if (menuScreen == 0)   {
    background(0)
    stroke(255);
    textSize(17)
    fill('rgb(218,159,53)')
    text('Recovery Rush', 160, 75);
    fill('white')
    text('Esc key for main menu', 140,400);

  }
  if (menuScreen == 1)   {
    setup();
  }
  //*************************************************************
  
  //***BELOW IS ALL OF THE CODE FOR STARTING GAME ONE***
  if (gameOneStatus == 0)   {
    stroke(255);
    textSize()
    text('Press 1 for Tracing Shapes!', 10, 150);
    image(menuTraceShape, 55, 165)
  }
  if (gameOneStatus == 1) {
    let playerOne;
    
    createCanvas(400, 400);
    background(0);
    fill(255);
    rect(120,50,150,40);
    fill(0);
    text('Tracing Shapes', 155, 75);
    fill(255);
    rect(200,350,170,40);
    fill('red');
    stroke(20);
    text('Press ESC for home', 230, 370);
    fill(255);
    rect(20,350,170,40);
    fill(0);
    text('Click on the circles that', 40, 370);
    text('match the pattern', 40, 380)
    fill(255);
    text("Score: " + score, 20, 120);
    
    userX = mouseX;
    userY = mouseY;
   
    fill(255);  
    playerOne = ellipse(userX, userY, userR,userR);
    
    
    square(150,180,100);
    
    fill(r1, g1, b1);
    ellipse(152,180,20,20);
    
    fill(r2, g2, b2);
    ellipse(247,180,20,20);
    
    fill(r3, g3, b3);
    ellipse(152,280,20,20);
    
    fill(r4, g4, b4);
    ellipse(247,280,20,20);
    
    if (score == 0)
      {
        image(shape1, 280, 180);
        if(circOneClicked == true && circTwoClicked != true && circThreeClicked == true && circFourClicked == true)
        {
          ++score;
          resetVars();
        }  else if (circTwoClicked == true)
          {
            resetVars();
          }
      }
    if (score == 1)
      {
       image(shape2, 280, 180);
       if (circOneClicked != true && circTwoClicked == true && circThreeClicked == true && circFourClicked == true)
         {
           ++score;
           resetVars();
         } else if(circOneClicked == true)
           {
             resetVars();
           }
      }
    if (score == 2)
      {
        image(shape3, 280, 180);
        if (circOneClicked == true && circTwoClicked == true && circThreeClicked == true && circFourClicked == true)
          {
            ++score;
            resetVars();
          } 
      }
   }
    
    if (gameOneStatus == 9)   {
      text('',0,0);
    }
  //***************************************************  
  //***BELOW IS ALL OF THE CODE FOR STARTING GAME TWO***
  if (gameTwoStatus == 0)   {
    stroke(255);
    fill('blue')
    text('Press 2 to start game two', 230, 150);
    text('for Maze Game', 230, 170);

  }
  if (gameTwoStatus == 1)   {
    text('',0,0);
    createCanvas(660,660);
    background('rgb(189,214,251)')
    rect(250,50,160,40);
    fill(0);
    textSize(15);
    text('Maze Game', 290, 75)
    fill('blue')
    textSize(22);
    textStyle(BOLD);
    textFont('Georgia');
    fill('Blue');  
    textSize(22);
    text('Recovery Rush', 450, 30)
    text('GAME 2', 530, 60)
    fill('Red');  
    text('START HERE', 30, 50)
    fill('Green');  
    text('END HERE', 530, 630)
    fill('blue');
    text('Avoid the wall and pass the maze', 40, 600);
    text('use arrow keys to move', 40, 640)
    
    textSize(80);
    fill('red');
    text(timer, width/6, height/1.2);
    if (frameCount % 60 == 0 && timer > 0) {
    timer --;
    }
    if (timer == 0) {
    textSize(100);
    fill('black');
    text("GAME OVER", width/290, height/1.9); 
  }
    fill(color);
    
  {
  
    if (keyIsDown(LEFT_ARROW)) {
        fill('yellow');
        x= X-= 2;
    }
  
    if (keyIsDown(RIGHT_ARROW)) {
         fill('yellow');
        x= X+= 2;
    }
  
    if (keyIsDown(UP_ARROW)) {
        fill('yellow');
        y= Y-= 2;
    }
  
    if (keyIsDown(DOWN_ARROW)) {
        fill('yellow');
        y= Y+= 2;
    }   
    ellipse(X, Y, 19, 19);
  } 
  
    fill('black');
    rect(50,60,5,60)
    rect(100,60, 5, 20);  
    rect(50,120, 50, 5);
    rect(100,80, 50, 5);
    rect(150, 80, 5, 235);
    rect(100,120, 5, 140);
    rect(15, 260, 90, 5);
    rect(60,310, 90, 5);
    rect(10,260,5,200)
    rect(60,310,5,105)
    rect(62,410, 95, 5);
    rect(10, 460, 140, 5);
    rect(150,190, 5, 90);
    rect(150,460,100,5)
    rect(155,410,50,5);
    rect(200,230, 5, 180);
    rect(250,280, 5, 185);
    rect(200,230,180,5);
    rect(250,280,80,5);
    rect(330,280, 5, 110);
    rect(380,230, 5, 120);
    rect(330,390,135,5);
    rect(380,350,140,5);
    rect(460,390,5, 65);
    rect(520,350,5, 140);
    rect(360,490,165,5);
    rect(300,450,160,5);
    rect(300,450,5, 120);
    rect(360,490,5, 40);
    rect(360,530,120,5);
    rect(300,570,130,5);
    rect(475,530,5, 75);
    rect(430,570,5, 80);
    rect(430,645,110,5);
    rect(480,600,60,5);      
       
      
    
    if(X == 50 && X == 60 && Y == 5 && Y == 60) {    
    safe = false;
    ready = 0;
    text('You Lose', 150,300);  
  }
    
    
    
     if(X > width || X < 0 || Y > height || Y < 2) {
    safe = false;
    text('You Lose', 150,300);   
  }   
    d = int(dist(x, y, 560, 650));
    // calculate the distance between the ninja and numchucks x1, y1, x2, y2
    
     if (d <60) {
    text('You win!', 150, 300);
    //go to different levels
  }    
    
  }
  
  //***************************************************
  
  //***BELOW IS ALL OF THE CODE FOR STARTING GAME THREE***
    if (gameThreeStatus == 0)   {
      stroke(255);
      fill('yellow')
      text('Press 3 to start game three', 20, 300);
      text('for Shapes Game', 20, 320);

      }
    if (gameThreeStatus == 1)   {
      text('',0,0);
      createCanvas(670,670);
      background('#EEEFA2');
  fill('black');
  rect(50, 160, 5, 260);
  rect(190, 160, 5, 260);
  rect(330, 160, 5, 260);
  rect(470, 160, 5, 260);
  rect(610, 160, 5, 260);
  rect(50, 160, 565, 5);
  rect(50, 200, 565, 5);
  rect(50, 420, 565, 5);
  textSize(80);
   
  
  text(timer2, width/1.3, height/8);
  if(frameCount % 60 == 0 && timer2 > 0) { 
    timer2 --;
  }
  if(timer2 == 0) {
    textSize(80);
    textStyle(BOLD);
    textFont('Georgia');
    fill('red')
    text("GAME OVER", width/8, height/1.15);
    
    button = createButton('Play again');
    button.position(width/1.4, height/1.4)
    button.mousePressed(resetSketch)
    
  }
  
   
  fill('rgb(187,8,8)');
  textSize(20);
  text('Recovery Rush', 70, 50)
  text('Matching colours', 70, 90)
  text('GAME 3', 70, 130)
  
  fill('rgb(19,19,239)')
  text('Blue', 90, 190)
  fill('brown')
  text('Brown', 230, 190)
  fill('rgb(13,177,13)')
  text('Green', 370, 190)
  fill('rgb(208,30,208)')
  text('Purple', 500, 190)
  
  
  textSize(20);
  fill('black')
  text('Click "b"', 80, 230)
  text('until Blue', 70, 250)
  
  fill('black')
  text('Click "r"', 220, 230)
  text('until Brown', 200, 250)
  
  fill('black')
  text('Click "g"', 360, 230)
  text('until Green', 340, 250)
  
  fill('black')
  text('Click "p"', 490, 230)
  text('until Purple', 480, 250)
  

  
  noStroke();
  fill(squareColor1)
  //fill('rgb(19,19,239)')
  square(90, 280, 70);
  
  noStroke();
  fill(squareColor2)
  //fill('brown')
  square(225, 280, 70);
  
  noStroke();
  fill(squareColor3)
  //fill('rgb(13,177,13)')
  square(365, 280, 70);
  
  noStroke();
  fill(squareColor4)
  //fill('rgb(231,31,231)')
  square(500, 280, 70); 
      }
      if (gameThreeStatus == 9)   {
      
      }
  
  //***************************************************
  
  //***BELOW IS ALL OF THE CODE FOR STARTING GAME FOUR***
    if (gameFourStatus == 0)   {
      fill(255);
      fill('green')
      text('Press 4 to start game four', 230, 300);
      text('for Balloon Game', 230, 320);

      }
    if (gameFourStatus == 1)   {
      createCanvas(400,400);
      background('green');
      fill(255);
      rect(120,50,150,40);
      fill(0);
      text('Game Four', 165, 75)
      }
    if (gameFourStatus == 9)   {
      text('',0,0);
      }
  //***************************************************
  }



//****BELOW IS ALL OF THE CODE FOR THE KEY INPUTS FROM THE USER****
function keyPressed()   {
  if (key === '1')   {
    gameOneStatus = 1;
    gameTwoStatus = 9;
    gameThreeStatus = 9;
    gameFourStatus = 9;
  }
  if (key === '2')   {
    gameTwoStatus = 1;
    gameOneStatus = 9;
    gameThreeStatus = 9;
    gameFourStatus = 9;
  }
  if (key === '3')   {
    gameThreeStatus = 1;
    gameOneStatus = 9;
    gameTwoStatus = 9;
    gameFourStatus = 9;
  }
  if (key === '4')   {
    gameFourStatus = 1;
    gameOneStatus = 9;
    gameTwoStatus = 9;
    gameThreeStatus = 9;
  }
  if (keyCode === ESCAPE)   {
    menuScreen = 1;
    score = 0;
    resetVars();
  }
}
//*****************************************************************




function mousePressed()    
     {
  let d1 = dist(mouseX,mouseY, 152, 180 );
  let d2 = dist(mouseX, mouseY, 247, 180);
  let d3 = dist(mouseX, mouseY, 152, 280);
  let d4 = dist(mouseX, mouseY, 247, 280);
    if (d1 < 10)   
      {
      r1 = 52;
      g1 = 235;
      b1 = 94;
      circOneClicked = true;
      }
    if (d2 < 10)   
    {
      r2 = 52;
      g2 = 235;
      b2 = 94;
      circTwoClicked = true;
    } 
  if (d3 < 10)   
    {
      r3 = 52;
      g3 = 235;
      b3 = 94;
      circThreeClicked = true;
    } 
    if (d4 < 10)   
    {
      r4 = 52;
      g4 = 235;
      b4 = 94;
      circFourClicked = true;
    } 
  }


function resetVars()
{
  r1 = 235;
  g1 = 26;
  b1 = 26;
  r2 = 235;
  g2 = 26;
  b2 = 26;
  r3 = 235;
  g3 = 26;
  b3 = 26;
  r4 = 235;
  g4 = 26;
  b4 = 26;
  circOneClicked = false;
  circTwoClicked = false;
  circThreeClicked = false;
  circFourClicked = false;
}

function win() {
  if((squareColor1 == 'blue') && (squareColor2 == 'brown') && (squareColor3 == 'green') && (squareColor4 == 'purple')) {
    timer2.stop()
  }
  fill('green')
  textSize(80);
  text('Congratulaulations! 100%', width/8, height/1.4); 
}

function resetSketch() {
  timer2 = 30
  squareColor1 = random(255);
  squareColor2 = random(255);
  squareColor3 = random(255);
  squareColor4 = random(255);
  
}

function drawColors() {
  squareColor1 = random(colorsArray);
  index = colorsArray.indexOf(squareColor1);
  colorsArray.splice(index, 1);
  squareColor2 = random(colorsArray);
  index = colorsArray.indexOf(squareColor2);
  colorsArray.splice(index, 1);
  squareColor3 = random(colorsArray);
  index = colorsArray.indexOf(squareColor3);
  colorsArray.splice(index, 1);
  squareColor4 = random(colorsArray);
  index = colorsArray.indexOf(squareColor4);
  wrongAnswer = random(options);
  
  answer1 = random(options);
  answer2 = random(options);
  answer3 = random(options);
  answer4 = random(options);
  
  solution1x = 0;
  solution1y = 0;
  solution2x = 0;
  solution2y = 0;
  solution3x = 0;
  solution3y = 0;
  solution4x = 0;
  solution4y = 0;
  
  if(answer1 == 0) {
    solution1x = 90;
    solution1y = 280;
  }
  else if(answer1 == 1) {
    solution1x = 225;
    solution1y = 280;
  }
  else if(answer1 == 2) {
    solution1x = 365;
    solution1y = 280;
  }
  else if(answer1 == 3) {
    solution1x = 500;
    solution1y = 280;
  }
  else if(answer2 == 0) {
    solution1x = 90;
    solution1y = 280;
  }
  else if(answer2 == 1) {
    solution1x = 225;
    solution1y = 280;
  }
  else if(answer2 == 2) {
    solution1x = 365;
    solution1y = 280;
  }
  else if(answer2 == 3) {
    solution1x = 500;
    solution1y = 100;
  }
  else if(answer3 == 0) {
    solution1x = 90;
    solution1y = 280;
  }
  else if(answer3 == 1) {
    solution1x = 225;
    solution1y = 280;
  }
  else if(answer3 == 2) {
    solution1x = 365;
    solution1y = 280;
  }
  else if(answer3 == 3) {
    solution1x = 500;
    solution1y = 280;
  }
  else if(answer4 == 0) {
    solution1x = 90;
    solution1y = 280;
  }
  else if(answer4 == 1) {
    solution1x = 225;
    solution1y = 280;
  }
  else if(answer4 == 2) {
    solution1x = 365;
    solution1y = 280;
  }
  else if(answer4 == 3) {
    solution1x = 500;
    solution1y = 280;
  }
  if(wrongAnswer == 0) {
    wrongX = 90;
    wrongY = 280;
  }
  else if(wrongAnswer == 1) {
    solution1x = 225;
    solution1y = 280;
  }
  else if(wrongAnswer == 2) {
    solution1x = 365;
    solution1y = 280;
  }
  else if(wrongAnswer == 3) {
    solution1x = 500;
    solution1y = 280;
  }
  loop()
}


function keyTyped(){
  if (key === 'b') {
    squareColor1 = (random(colorsArray));
    //answer1 = random(colorsArray);
    options.splice(colorsArray.indexOf(answer1), 1);
  }
  
  else if (key === 'r') {
    squareColor2 = (random(colorsArray));
    //answer2 = random(colorsArray);
    options.splice(colorsArray.indexOf(answer2), 1);
  }
  
  else if (key === 'g') {
    squareColor3 = (random(colorsArray));
    //answer3 = random(colorsArray);
    options.splice(colorsArray.indexOf(answer3), 1);
  }
  
  else if (key === 'p') {
    squareColor4 = (random(colorsArray));
    //answer4 = random(colorsArray);
    options.splice(colorsArray.indexOf(answer4), 1);
  }
}



