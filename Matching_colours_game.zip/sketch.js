let timer = 30
let squareColor1 = 0;
let squareColor2 = 0;
let squareColor3 = 0;
let squareColor4 = 0;
let button;
let options = [0, 1, 2, 3];
let answer1;
let answer2;
let answer3;
let answer4;

let colorsArray = ['blue', 'green', 'purple', 'brown', 'magenta', 'tan', 'white', 'yellow', 'red', 'turquoise']

//let btn;


function setup() {
  createCanvas(670, 670);
  fill(255);
  textStyle(BOLD);
  textFont('Georgia');
  squareColor1 = random(255);
  squareColor2 = random(255);
  squareColor3 = random(255);
  squareColor4 = random(255);
  
  //btn = createButton('Submit');
  //btn.position(width/8, height/1.4);
  //btn.mousePressed(feedback);
    
}
/*
function feedback() {
  if (timer != 0) {
    text('Well Done!', width/8, height/1.4)
  }
}
*/

function draw() 
{  
  background('#EEEFA2');
  fill('black');
  rect(50, 160, 5, 260);
  rect(190, 160, 5, 260);
  rect(330, 160, 5, 260);
  rect(470, 160, 5, 260);
  rect(610, 160, 5, 260);
  rect(50, 160, 565, 5);
  rect(50, 200, 565, 5);
  rect(50, 420, 565, 5);
  textSize(80);
   
  
  text(timer, width/1.3, height/8);
  if(frameCount % 60 == 0 && timer > 0) { 
    timer --;
  }
  if(timer == 0) {
    textSize(80);
    textStyle(BOLD);
    textFont('Georgia');
    fill('red')
    text("GAME OVER", width/8, height/1.15);
    
    button = createButton('Play again');
    button.position(width/1.4, height/1.4)
    button.mousePressed(resetSketch)
    
  }
  
   
  fill('rgb(187,8,8)');
  textSize(20);
  text('Recovery Rush', 70, 50)
  text('Matching colours', 70, 90)
  text('GAME 3', 70, 130)
  
  fill('rgb(19,19,239)')
  text('Blue', 90, 190)
  fill('brown')
  text('Brown', 230, 190)
  fill('rgb(13,177,13)')
  text('Green', 370, 190)
  fill('rgb(208,30,208)')
  text('Purple', 500, 190)
  
  
  textSize(20);
  fill('black')
  text('Click "b"', 80, 230)
  text('until Blue', 70, 250)
  
  fill('black')
  text('Click "r"', 220, 230)
  text('until Brown', 200, 250)
  
  fill('black')
  text('Click "g"', 360, 230)
  text('until Green', 340, 250)
  
  fill('black')
  text('Click "p"', 490, 230)
  text('until Purple', 480, 250)
  

  
  noStroke();
  fill(squareColor1)
  //fill('rgb(19,19,239)')
  square(90, 280, 70);
  
  noStroke();
  fill(squareColor2)
  //fill('brown')
  square(225, 280, 70);
  
  noStroke();
  fill(squareColor3)
  //fill('rgb(13,177,13)')
  square(365, 280, 70);
  
  noStroke();
  fill(squareColor4)
  //fill('rgb(231,31,231)')
  square(500, 280, 70); 

}

function win() {
  if((squareColor1 == 'blue') && (squareColor2 == 'brown') && (squareColor3 == 'green') && (squareColor4 == 'purple')) {
    timer.stop()
  }
  fill('green')
  textSize(80);
  text('Congratulaulations! 100%', width/8, height/1.4); 
}

function resetSketch() {
  timer = 30
  setup();
}

function drawColors() {
  squareColor1 = random(colorsArray);
  index = colorsArray.indexOf(squareColor1);
  colorsArray.splice(index, 1);
  squareColor2 = random(colorsArray);
  index = colorsArray.indexOf(squareColor2);
  colorsArray.splice(index, 1);
  squareColor3 = random(colorsArray);
  index = colorsArray.indexOf(squareColor3);
  colorsArray.splice(index, 1);
  squareColor4 = random(colorsArray);
  index = colorsArray.indexOf(squareColor4);
  wrongAnswer = random(options);
  
  answer1 = random(options);
  answer2 = random(options);
  answer3 = random(options);
  answer4 = random(options);
  
  solution1x = 0;
  solution1y = 0;
  solution2x = 0;
  solution2y = 0;
  solution3x = 0;
  solution3y = 0;
  solution4x = 0;
  solution4y = 0;
  
  if(answer1 == 0) {
    solution1x = 90;
    solution1y = 280;
  }
  else if(answer1 == 1) {
    solution1x = 225;
    solution1y = 280;
  }
  else if(answer1 == 2) {
    solution1x = 365;
    solution1y = 280;
  }
  else if(answer1 == 3) {
    solution1x = 500;
    solution1y = 280;
  }
  else if(answer2 == 0) {
    solution1x = 90;
    solution1y = 280;
  }
  else if(answer2 == 1) {
    solution1x = 225;
    solution1y = 280;
  }
  else if(answer2 == 2) {
    solution1x = 365;
    solution1y = 280;
  }
  else if(answer2 == 3) {
    solution1x = 500;
    solution1y = 100;
  }
  else if(answer3 == 0) {
    solution1x = 90;
    solution1y = 280;
  }
  else if(answer3 == 1) {
    solution1x = 225;
    solution1y = 280;
  }
  else if(answer3 == 2) {
    solution1x = 365;
    solution1y = 280;
  }
  else if(answer3 == 3) {
    solution1x = 500;
    solution1y = 280;
  }
  else if(answer4 == 0) {
    solution1x = 90;
    solution1y = 280;
  }
  else if(answer4 == 1) {
    solution1x = 225;
    solution1y = 280;
  }
  else if(answer4 == 2) {
    solution1x = 365;
    solution1y = 280;
  }
  else if(answer4 == 3) {
    solution1x = 500;
    solution1y = 280;
  }
  if(wrongAnswer == 0) {
    wrongX = 90;
    wrongY = 280;
  }
  else if(wrongAnswer == 1) {
    solution1x = 225;
    solution1y = 280;
  }
  else if(wrongAnswer == 2) {
    solution1x = 365;
    solution1y = 280;
  }
  else if(wrongAnswer == 3) {
    solution1x = 500;
    solution1y = 280;
  }
  loop()
}

function keyTyped(){
  if (key === 'b') {
    squareColor1 = color(random(colorsArray));
    //answer1 = random(colorsArray);
    options.splice(colorsArray.indexOf(answer1), 1);
  }
  
  else if (key === 'r') {
    squareColor2 = color(random(colorsArray));
    //answer2 = random(colorsArray);
    options.splice(colorsArray.indexOf(answer2), 1);
  }
  
  else if (key === 'g') {
    squareColor3 = color(random(colorsArray));
    //answer3 = random(colorsArray);
    options.splice(colorsArray.indexOf(answer3), 1);
  }
  
  else if (key === 'p') {
    squareColor4 = color(random(colorsArray));
    //answer4 = random(colorsArray);
    options.splice(colorsArray.indexOf(answer4), 1);
  }
}

//(175, 100, 220), (127, 0, 0), (90, 25, 30), (255, 50, 255)





